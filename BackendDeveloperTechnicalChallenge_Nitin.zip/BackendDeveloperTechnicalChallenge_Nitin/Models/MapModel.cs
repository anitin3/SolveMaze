﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SolveMazeApi.Models
{
    public class MapModel
    {
        public string Map { get; set; }
    }
}