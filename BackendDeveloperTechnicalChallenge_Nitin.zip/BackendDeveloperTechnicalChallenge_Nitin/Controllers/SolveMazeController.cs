﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SolveMazeApi.Models;
using System.Text;

namespace SolveMazeApi.Controllers
{
    public class SolveMazeController : ApiController
    {
        int nrRows = 0;
        int nColumns = 0;
        int nSteps = 0;
        int xStart = 0;
        int yStart = 0;
        string solution = string.Empty;
        char[,] finalMaze = null;

     
        [Route("solveMaze")]       
        public SolveResultModel Post([FromBody] MapModel Input)
        {
            try
            {
                if(!Input.Equals(null) && !Input.Map.Trim().Equals(string.Empty))
                ProcessMaze(Input.Map);
                return new SolveResultModel() { Steps = nSteps, Solution = solution };
            }
            catch
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
        }

        /// <summary>
        /// Accepts the map as input and processes it with 
        /// </summary>
        /// <param name="input"></param>
        private void ProcessMaze(String input)
        {

            //getting the rows and columns of the Maze
            List<string> Rows = new List<string>(
                           input.Split(new string[] { "\r\n", "\n" },
                           StringSplitOptions.None));
            nrRows = Rows.Count();
            nColumns = Rows[0].Length;

            //Converting string to Array
            finalMaze = new char[nrRows, nColumns];
            int r = 0, c = 0;
            foreach (string row in Rows)
            {
                foreach (Char car in row)
                {
                    finalMaze[r, c] = car;
                    //Recording the starting point
                    if (car.Equals('A'))
                    {
                        xStart = r;
                        yStart = c;
                    }
                    c++;
                }
                c = 0; r++;
            }
            bool[,] alreadySearched = new bool[nrRows, nColumns];
            if (!solveMazePv(xStart, yStart, alreadySearched))
            {
                nSteps = 0;
                solution ="Maze cannot Be solved";
            }
            else
            {
                solution = retSolution(); ;
            }
        }

        /// <summary>
        /// Method which actually traverses the maze recursively
        /// </summary>
        /// <param name="xPos"></param>
        /// <param name="yPos"></param>
        /// <param name="alreadySearched"></param>
        /// <returns></returns>
        private bool solveMazePv(int xPos, int yPos, bool[,] alreadySearched)
        {
            bool correctPath = false;
            //should the computer check this tile
            bool shouldCheck = true;
            //Check for out of boundaries
            if (xPos >= nrRows || xPos < 0 || yPos >= nColumns || yPos < 0)
                shouldCheck = false;
            else
            {
                //Check if at finish, not (0,0 and colored light blue)
                if (finalMaze[xPos, yPos].Equals('B') && (xPos != 0 && yPos != 0))
                {
                    correctPath = true;
                    shouldCheck = false;
                }

                //Check for a wall
                if (finalMaze[xPos, yPos].Equals('#'))
                    shouldCheck = false;

                //Check if previously searched
                if (alreadySearched[xPos, yPos])
                {
                    shouldCheck = false;
                    if (finalMaze[xPos, yPos].Equals('@'))
                    {
                        finalMaze[xPos, yPos] = '.';
                    }
                }
            }

            //Search the Tile
            if (shouldCheck)
            {
                //mark location as searched
                alreadySearched[xPos, yPos] = true;

                //Check down 
                correctPath = correctPath || solveMazePv(xPos + 1, yPos, alreadySearched);
                //Check  right
                correctPath = correctPath || solveMazePv(xPos, yPos + 1, alreadySearched);
                //check up 
                correctPath = correctPath || solveMazePv(xPos - 1, yPos, alreadySearched);
                //check  Left
                correctPath = correctPath || solveMazePv(xPos, yPos - 1, alreadySearched);
            }

            //mark correct path @
            if (correctPath)
            {

                if (!(finalMaze[xPos, yPos].Equals('A') || finalMaze[xPos, yPos].Equals('B') || finalMaze[xPos, yPos].Equals('#')))
                    finalMaze[xPos, yPos] = '@';
                nSteps++;
            }

            return correctPath;

        }
       
        /// <summary>
        /// Converts are 2d array to a single string after operation
        /// </summary>
        /// <returns></returns>
        private string retSolution()
        {

            StringBuilder sol = new StringBuilder();
            for (int i = 0; i < nrRows; i++)
            {
                for (int j = 0; j < nColumns; j++)
                {
                    sol.Append(finalMaze[i, j]);
                }
                sol.Append(System.Environment.NewLine);
            }

            return sol.ToString();
        }

    }
}




